const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 8080 });
const fakeData = require("./fakeData");

wss.on("connection", function connection(ws) {
  console.log("server socket connection");

  ws.on("message", (message) => {
    console.log("server socket message", JSON.parse(message)); // message: {type: "search", data: {type: "ip", searchData: ""}}
    const request = JSON.parse(message);
    let response = "데이터 없음";

    switch (request.type) {
      case "search":
        console.log("%%%%%%%", fakeData.searchData[request.data.type]);
        response = {
          type: "search",
          data: fakeData.searchData[request.data.type],
        };
        break;
      default:
        break;
    }

    wss.clients.forEach((client) => {
      console.log("client에게 메세지 전송");

      if (client === ws && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(response));
      }
    });
  });
});
